import 'package:app_music/ui/home/home.dart';
import 'package:flutter/material.dart';
void main() {
  runApp(const MusicApp());
}
