package com.example.app_music

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
